
package teamschedulerdemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.TreeMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;
import java.util.Collection;

public class RegularRefereeViewWindow extends javax.swing.JFrame {
    
    //creat team total scores here and save their scores here
int counter = 0;
String team1Name = "";
String team2Name = "";
String team3Name = "";
String team4Name = "";
String team5Name = "";
String team6Name = "";
String team7Name = "";
String team8Name = "";
String team9Name = "";
String team10Name = "";

int team1totScore = 0;
int team2totScore = 0;
int team3totScore = 0;
int team4totScore = 0;
int team5totScore = 0;
int team6totScore = 0;
int team7totScore = 0;
int team8totScore = 0;
int team9totScore = 0;
int team10totScore = 0;

int team1totPoints = 0;
int team2totPoints = 0;
int team3totPoints = 0;
int team4totPoints = 0;
int team5totPoints = 0;
int team6totPoints = 0;
int team7totPoints = 0;
int team8totPoints = 0;
int team9totPoints = 0;
int team10totPoints = 0;

PrintWriter outTeam1, outTeam2,outTeam3,outTeam4,outTeam5,outTeam6,outTeam7,outTeam8,outTeam9,outTeam10, outRounds;
BufferedReader inTeam1, inTeam2,inTeam3,inTeam4,inTeam5,inTeam6,inTeam7,inTeam8,inTeam9,inTeam10;

ScheduleView frame;
    public RegularRefereeViewWindow() {
        
        initComponents();
        setVisible(true); 
        String[] labels = new String[10];
        
        try{ 
            String inputFile = "TEAM_NAMES.txt";
            String line =null;
            String lines =null;
            String temp;
            
            BufferedReader in = new BufferedReader(new FileReader(inputFile));
            BufferedReader input = new BufferedReader(new FileReader(inputFile));
      while ((line = in.readLine()) !=null)
      {
        temp = line;
          team1Label.setText(temp);
          jLabel2.setText(in.readLine());
          jLabel3.setText(in.readLine());
          jLabel4.setText(in.readLine());
          jLabel5.setText(in.readLine());
          jLabel6.setText(in.readLine());
          jLabel7.setText(in.readLine());
          jLabel8.setText(in.readLine());
          jLabel9.setText(in.readLine());
          jLabel10.setText(in.readLine());
          
        break;
      }
      
      // read in names
         while ((lines = input.readLine()) !=null)
         {
      
             team1Name = lines;
             team2Name = input.readLine();
             team3Name = input.readLine();
             team4Name = input.readLine();
             team5Name = input.readLine();
             team6Name = input.readLine();
             team7Name = input.readLine();
             team8Name = input.readLine();
             team9Name = input.readLine();
             team10Name = input.readLine();
            
             break;
      
      
         }
        // System.out.println(team1Name+ " hello "+ team2Name + " hello "+ team3Name);
         outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
         outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
         outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
         outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
         outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
         outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
         outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
         outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
         outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
         outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
         
         
         
         outTeam1.printf(team1Name+"\n"+team1totPoints+"\n");
         outTeam2.printf(team2Name+"\n"+team2totPoints+"\n");
         outTeam3.printf(team3Name+"\n"+team3totPoints+"\n");
         outTeam4.printf(team4Name+"\n"+team4totPoints+"\n");
         outTeam5.printf(team5Name+"\n"+team5totPoints+"\n");
         outTeam6.printf(team6Name+"\n"+team6totPoints+"\n");
         outTeam7.printf(team7Name+"\n"+team7totPoints+"\n");
         outTeam8.printf(team8Name+"\n"+team8totPoints+"\n");
         outTeam9.printf(team9Name+"\n"+team9totPoints+"\n");
         outTeam10.printf(team10Name+"\n"+team10totPoints+"\n");
         
         outTeam1.close();
         outTeam2.close();
         outTeam3.close();
         outTeam4.close();
         outTeam5.close();
         outTeam6.close();
         outTeam7.close();
         outTeam8.close();
         outTeam9.close();
         outTeam10.close();
         
        // getTeamTotalScores();
         
    }
    catch (Exception e)
    {
     // e.printStackTrace();
        JOptionPane.showMessageDialog (null,"There has been problem with the data. Please contact "
                  + "customer care representative!");
        
        System.exit(0);
    } 
        frame = new ScheduleView();
        frame.setVisible(true);
       
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        headerField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        team1Label = new javax.swing.JLabel();
        teamHeaderLabel = new javax.swing.JLabel();
        teamScoreLabel = new javax.swing.JLabel();
        team1TextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();

        headerField.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        headerField.setText("Regular Referee View Window");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Regular Referee");
        setFocusable(true);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel1.setText("Regular Referee View Window");

        team1Label.setText("Team 1");

        teamHeaderLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        teamHeaderLabel.setText("Team Names");

        teamScoreLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        teamScoreLabel.setText("Team Scores");

        jLabel2.setText("Team 2");

        jLabel3.setText("Team 3");

        jLabel4.setText("Team 4");

        jLabel5.setText("Team 5");

        jLabel6.setText("Team 6");

        jLabel7.setText("Team 7");

        jLabel8.setText("Team 8");

        jLabel9.setText("Team 9");

        jLabel10.setText("Team 10");

        saveButton.setText("Save");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(teamHeaderLabel)
                            .addComponent(team1Label)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(204, 204, 204)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(teamScoreLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(team1TextField)
                            .addComponent(jTextField1)
                            .addComponent(jTextField2)
                            .addComponent(jTextField3)
                            .addComponent(jTextField4)
                            .addComponent(jTextField5)
                            .addComponent(jTextField6)
                            .addComponent(jTextField7)
                            .addComponent(jTextField8)
                            .addComponent(jTextField9)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(saveButton)
                        .addGap(85, 85, 85)
                        .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(teamHeaderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(teamScoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(team1Label)
                    .addComponent(team1TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        // TODO add your handling code here:
        dispose();
        frame.dispose();
       // System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
       try{
           
        int team1Score = Integer.parseInt(team1TextField.getText()); 
        int team2Score = Integer.parseInt(jTextField1.getText());        
        int team3Score = Integer.parseInt(jTextField2.getText());
        int team4Score = Integer.parseInt(jTextField3.getText());
        int team5Score = Integer.parseInt(jTextField4.getText());
        int team6Score = Integer.parseInt(jTextField5.getText());
        int team7Score = Integer.parseInt(jTextField6.getText());
        int team8Score = Integer.parseInt(jTextField7.getText());
        int team9Score = Integer.parseInt(jTextField8.getText());
        int team10Score = Integer.parseInt(jTextField9.getText());
       
        Object source = evt.getSource();          //gets action performed
        
            if (counter==0)
            {
            outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
            outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
            outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
            outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
            outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
            outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
            outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
            outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
            outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
            outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
            
            outTeam1.printf(team1Name+"\n");
            outTeam2.printf(team2Name+"\n");
            outTeam3.printf(team3Name+"\n");
            outTeam4.printf(team4Name+"\n");
            outTeam5.printf(team5Name+"\n");
            outTeam6.printf(team6Name+"\n");
            outTeam7.printf(team7Name+"\n");
            outTeam8.printf(team8Name+"\n");
            outTeam9.printf(team9Name+"\n");
            outTeam10.printf(team10Name+"\n");
            
           // System.out.println("Yo testing to see if this method works");
            }
            System.out.println("Button Clicked");
            
        if (source == saveButton)
        {
            System.out.println(" from source method");
       
            counter++;
            
            switch (counter)
            {
                
                case 1 :
                    System.out.println("Testing from case ---> " + counter );
                    
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if (team1Score > team10Score){
                        team1totScore += 3;
                       
                        outTeam1.printf(""+ team1totScore+"\n");
                        
                    }
                    else if(team1Score < team10Score)
                    {
                        team10totScore += 3;
                        
                        outTeam10.printf(""+ team10totScore+"\n");
                    }
                    
                    else if (team1Score == team10Score){
                        team1totScore +=1;
                        team10totScore +=1;
                        System.out.println("Team one tot score"+team1totScore +"Team 10 tot Score" +team10totScore);
                        outTeam1.printf(""+ team1totScore+"\n");
                        outTeam10.printf(""+ team10totScore+"\n");
                    }
                    
                    if (team2Score > team9Score){
                        
                        team2totScore += 3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if(team2Score < team9Score){
                        team9totScore += 3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    
                    else if(team2Score == team9Score){
                        team2totScore +=1;
                        team9totScore +=1;
                        outTeam2.printf(""+team2totScore+"\n");
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    
                    if (team3Score > team8Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if(team3Score < team8Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    else if(team3Score == team8Score ){
                        team3totScore +=1;
                        team8totScore +=1;
                        outTeam3.printf(""+team3totScore+"\n");
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    
                    if(team4Score > team7Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team4Score < team7Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    
                   }
                    else if (team4Score == team7Score){
                        team4totScore +=1;
                        team7totScore +=1;
                        outTeam4.printf(""+team4totScore+"\n");
                        outTeam7.printf(""+team7totScore+"\n");
                        
                    }
                    
                    if (team5Score > team6Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");  
                        
                    }
                    
                    else if (team5Score < team6Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                        
                    }
                    
                    else if (team5Score == team6Score)
                    {
                     team5totScore +=1;
                     team6totScore +=1;
                     
                     outTeam5.printf(""+team5totScore+"\n");
                     outTeam6.printf(""+team6totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 1\n"+team1Name+" "+team1Score+"-"+team10Score+" "+team10Name+"\n"
                                                +team2Name+" "+team2Score+"-"+ team9Score +" "+team9Name+"\n"
                                                +team3Name+" "+team3Score+"-"+ team8Score +" "+team8Name+"\n"
                                                +team4Name+" "+team4Score+"-"+ team7Score +" "+team7Name+"\n"
                                                +team5Name+" "+team5Score+"-"+ team6Score +" "+team6Name+"\n");
                    outRounds.close();
                    
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!"); 
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    
                    break;
                case 2 : 
                    System.out.println("Hello from case --->" + counter);
                    
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if (team1Score > team9Score){
                        team1totScore +=3;
                        outTeam1.printf(""+ team1totScore+"\n");
                        outTeam1.close();
                    }
                    else if(team1Score < team9Score){
                        team9totScore +=3;
                        outTeam9.printf(""+ team9totScore+"\n");
                    }
                    
                    else if(team1Score == team9Score){
                        team1totScore +=1;
                        team9totScore +=1;
                        
                        outTeam1.printf(""+ team1totScore+"\n");
                        outTeam9.printf(""+ team9totScore+"\n");
                    }
                    if (team10Score > team8Score){
                        team10totScore +=3;
                        outTeam10.printf(""+ team10totScore+"\n");
                        
                    }
                    else if(team10Score < team8Score){
                       team8totScore +=3;
                       outTeam8.printf(""+ team8totScore+"\n"); 
                    }
                    else if(team10Score == team8Score){
                        team10totScore +=1;
                        team8totScore +=1;
                        
                        outTeam8.printf(""+ team8totScore+"\n");
                        outTeam10.printf(""+ team10totScore+"\n");
                    }
                    
                    if (team2Score > team7Score){
                        team2totScore +=3;
                        outTeam2.printf(""+ team2totScore+"\n"); 
                    }
                    else if(team2Score < team7Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    else if(team2Score == team7Score){
                        team2totScore +=1;
                        team7totScore +=1;
                        outTeam2.printf(""+ team2totScore+"\n");
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    if (team3Score > team6Score){
                       team3totScore +=3;
                       outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team3Score < team6Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    else if(team3Score == team6Score){
                        team3totScore +=1;
                        team6totScore +=1;
                        outTeam3.printf(""+team3totScore+"\n");
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    if (team4Score > team5Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team4Score < team5Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    else if (team4Score == team5Score){
                        team5totScore +=1;
                        team4totScore +=1;
                        outTeam4.printf(""+team4totScore+"\n");
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                  
                    outRounds.printf("Round 2\n"+team1Name+" "+team1Score+"-"+team9Score+" "+team9Name+"\n"
                                                +team10Name+" "+team10Score+"-"+ team8Score +" "+team8Name+"\n"
                                                +team2Name+" "+team2Score+"-"+ team7Score +" "+team7Name+"\n"
                                                +team3Name+" "+team3Score+"-"+ team6Score +" "+team6Name+"\n"
                                                +team4Name+" "+team4Score+"-"+ team5Score +" "+team5Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0; 
                   break;
                case 3: 
                    System.out.println("Hello from case --->" + counter);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if (team1Score > team8Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    else if ( team1Score < team8Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    else if (team1Score == team8Score){
                      team1totScore +=1;  
                      team8totScore +=1;
                      outTeam1.printf(""+team1totScore+"\n");
                      outTeam8.printf(""+team8totScore+"\n");
                    }
                    if (team9Score > team7Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    else if(team9Score < team7Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    else if (team9Score == team7Score){
                        team9totScore +=1;
                        team7totScore +=1;
                        outTeam9.printf(""+team9totScore+"\n");
                        outTeam7.printf(""+team7totScore+"\n");
                        
                    }
                    if (team10Score > team6Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                        
                    }
                    else if (team10Score < team6Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    else if (team10Score == team6Score){
                        team6totScore +=1;
                        team10totScore +=1;
                        outTeam10.printf(""+team10totScore+"\n");
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    if (team2Score > team5Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team2Score < team5Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    else if(team2Score == team5Score){
                        team2totScore +=1;
                        team5totScore +=1;
                        outTeam2.printf(""+team2totScore+"\n");
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    if (team3Score > team4Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team3Score < team4Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team3Score == team4Score){
                        team3totScore +=1;
                        team4totScore +=1;
                        outTeam3.printf(""+team3totScore+"\n");
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                   
                    outRounds.printf("Round 3\n"+team1Name+" "+team1Score+"-"+team8Score+" "+team8Name+"\n"
                                                +team9Name+" "+team9Score+"-"+ team7Score +" "+team7Name+"\n"
                                                +team10Name+" "+team10Score+"-"+ team6Score +" "+team6Name+"\n"
                                                +team2Name+" "+team2Score+"-"+ team5Score +" "+team5Name+"\n"
                                                +team3Name+" "+team3Score+"-"+ team4Score +" "+team4Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0; 
                    //setVisible(true);
                    break;
                case 4: 
                    System.out.println("Hello from case --->" + counter);
                    //setVisible(true);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if(team1Score > team7Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team7Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    else if (team1Score == team7Score){
                        team1totScore +=1;
                        team7totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    if(team8Score > team6Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    
                    else if (team8Score < team6Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    else if (team8Score == team6Score){
                        team8totScore +=1;
                        team6totScore +=1;
                        outTeam8.printf(""+team8totScore+"\n");
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    
                    
                    if(team9Score > team5Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    
                    else if (team9Score < team5Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    else if (team9Score == team5Score){
                        team9totScore +=1;
                        team5totScore +=1;
                        outTeam9.printf(""+team9totScore+"\n");
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    
                    if(team10Score > team4Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    
                    else if (team10Score < team4Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team10Score == team4Score){
                        team10totScore +=1;
                        team4totScore +=1;
                        outTeam10.printf(""+team10totScore+"\n");
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    
                    if(team2Score > team3Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    
                    else if (team2Score < team3Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team2Score == team3Score){
                        team2totScore +=1;
                        team3totScore +=1;
                        outTeam2.printf(""+team2totScore+"\n");
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 4\n"+team1Name+" "+team1Score+"-"+team7Score+" "+team7Name+"\n"
                                                +team8Name+" "+team8Score+"-"+ team6Score +" "+team6Name+"\n"
                                                +team9Name+" "+team9Score+"-"+ team5Score +" "+team5Name+"\n"
                                                +team10Name+" "+team10Score+"-"+ team4Score +" "+team4Name+"\n"
                                                +team2Name+" "+team2Score+"-"+ team3Score +" "+team3Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    break;
                case 5: 
                    System.out.println("Hello from case --->" + counter);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    //
                    if(team1Score > team6Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team6Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    else if (team1Score == team6Score){
                        team1totScore +=1;
                        team6totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    //
                    if(team7Score > team5Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    else if (team7Score < team5Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    else if (team7Score == team5Score){
                        team7totScore +=1;
                        team5totScore +=1;
                        outTeam7.printf(""+team7totScore+"\n");
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    //
                    if(team8Score > team4Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    
                    else if (team8Score < team4Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team8Score == team4Score){
                        team8totScore +=1;
                        team4totScore +=1;
                        outTeam8.printf(""+team8totScore+"\n");
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    //
                    if(team9Score > team3Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    
                    else if (team9Score < team3Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team9Score == team3Score){
                        team9totScore +=1;
                        team3totScore +=1;
                        outTeam9.printf(""+team9totScore+"\n");
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    //
                    if(team10Score > team2Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    
                    else if (team10Score < team2Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team10Score == team2Score){
                        team10totScore +=1;
                        team2totScore +=1;
                        outTeam10.printf(""+team10totScore+"\n");
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    //setVisible(true);
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 5\n"+team1Name+" "+team1Score+"-"+team6Score+" "+team6Name+"\n"
                                                +team7Name+" "+team7Score+"-"+ team5Score +" "+team5Name+"\n"
                                                +team8Name+" "+team8Score+"-"+ team4Score +" "+team4Name+"\n"
                                                +team9Name+" "+team9Score+"-"+ team3Score +" "+team3Name+"\n"
                                                +team10Name+" "+team10Score+"-"+ team2Score +" "+team2Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    break;
                case 6 : 
                    System.out.println("Hello from case --->" + counter);
                    
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if(team1Score > team5Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team5Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    else if (team1Score == team5Score){
                        team1totScore +=1;
                        team5totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    //
                    if(team6Score > team4Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    
                    else if (team6Score < team4Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team6Score == team4Score){
                        team6totScore +=1;
                        team4totScore +=1;
                        outTeam6.printf(""+team6totScore+"\n");
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    //
                    if(team7Score > team3Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    else if (team7Score < team3Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team7Score == team3Score){
                        team7totScore +=1;
                        team3totScore +=1;
                        outTeam7.printf(""+team7totScore+"\n");
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    //
                    if(team8Score > team2Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    
                    else if (team8Score < team2Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team8Score == team2Score){
                        team8totScore +=1;
                        team2totScore +=1;
                        outTeam8.printf(""+team8totScore+"\n");
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    //
                    if(team9Score > team10Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    
                    else if (team9Score < team10Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    else if (team9Score == team10Score){
                        team9totScore +=1;
                        team10totScore +=1;
                        outTeam9.printf(""+team9totScore+"\n");
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 6\n"+team1Name+" "+team1Score+"-"+team5Score+" "+team5Name+"\n"
                                                +team6Name+" "+team6Score+"-"+ team4Score +" "+team4Name+"\n"
                                                +team7Name+" "+team7Score+"-"+ team3Score +" "+team3Name+"\n"
                                                +team8Name+" "+team8Score+"-"+ team2Score +" "+team2Name+"\n"
                                                +team9Name+" "+team9Score+"-"+ team10Score +" "+team10Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                   break;
                case 7: 
                    System.out.println("Hello from case --->" + counter);
                    //setVisible(true);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if(team1Score > team4Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team4Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    else if (team1Score == team4Score){
                        team1totScore +=1;
                        team4totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    //
                    if(team5Score > team3Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    
                    else if (team5Score < team3Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team5Score == team3Score){
                        team5totScore +=1;
                        team3totScore +=1;
                        outTeam5.printf(""+team5totScore+"\n");
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    //
                    if(team6Score > team2Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    
                    else if (team6Score < team2Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team6Score == team2Score){
                        team6totScore +=1;
                        team2totScore +=1;
                        outTeam6.printf(""+team6totScore+"\n");
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    //
                    if(team7Score > team10Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    else if (team7Score < team10Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    else if (team7Score == team10Score){
                        team7totScore +=1;
                        team10totScore +=1;
                        outTeam7.printf(""+team7totScore+"\n");
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    //
                    if(team8Score > team9Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    
                    else if (team8Score < team9Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    else if (team8Score == team9Score){
                        team8totScore +=1;
                        team9totScore +=1;
                        outTeam8.printf(""+team8totScore+"\n");
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 7\n"+team1Name+" "+team1Score+"-"+team4Score+" "+team4Name+"\n"
                                                +team5Name+" "+team5Score+"-"+ team3Score +" "+team3Name+"\n"
                                                +team6Name+" "+team6Score+"-"+ team2Score +" "+team2Name+"\n"
                                                +team7Name+" "+team7Score+"-"+ team10Score +" "+team10Name+"\n"
                                                +team8Name+" "+team8Score+"-"+ team9Score +" "+team9Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    break;
                case 8: 
                    System.out.println("Hello from case --->" + counter);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if(team1Score > team3Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team3Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    else if (team1Score == team3Score){
                        team1totScore +=1;
                        team3totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    //
                    if(team4Score > team2Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    
                    else if (team4Score < team2Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team4Score == team2Score){
                        team4totScore +=1;
                        team2totScore +=1;
                        outTeam4.printf(""+team4totScore+"\n");
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    //
                    if(team5Score > team10Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    
                    else if (team5Score < team10Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    else if (team5Score == team10Score){
                        team5totScore +=1;
                        team10totScore +=1;
                        outTeam5.printf(""+team5totScore+"\n");
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    //
                    if(team6Score > team9Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    
                    else if (team6Score < team9Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    else if (team6Score == team9Score){
                        team6totScore +=1;
                        team9totScore +=1;
                        outTeam6.printf(""+team6totScore+"\n");
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    //
                    if(team7Score > team8Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    else if (team7Score < team8Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    else if (team7Score == team8Score){
                        team7totScore +=1;
                        team8totScore +=1;
                        outTeam7.printf(""+team7totScore+"\n");
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 8\n"+team1Name+" "+team1Score+"-"+team3Score+" "+team3Name+"\n"
                                                +team4Name+" "+team4Score+"-"+ team2Score +" "+team2Name+"\n"
                                                +team5Name+" "+team5Score+"-"+ team10Score +" "+team10Name+"\n"
                                                +team6Name+" "+team6Score+"-"+ team9Score +" "+team9Name+"\n"
                                                +team7Name+" "+team7Score+"-"+ team8Score +" "+team8Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    
                    break;
                case 9: 
                    System.out.println("Hello from case --->" + counter);
                    outTeam1 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM1.txt",true)));
                    outTeam2 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM2.txt",true)));
                    outTeam3 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM3.txt",true)));
                    outTeam4 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM4.txt",true)));
                    outTeam5 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM5.txt",true)));
                    outTeam6 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM6.txt",true)));
                    outTeam7 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM7.txt",true)));
                    outTeam8 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM8.txt",true)));
                    outTeam9 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM9.txt",true)));
                    outTeam10 = new PrintWriter (new BufferedWriter(new FileWriter("TEAM10.txt",true)));
                    outRounds = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS_.txt",true)));
                    
                    if(team1Score > team2Score){
                        team1totScore +=3;
                        outTeam1.printf(""+team1totScore+"\n");
                    }
                    
                    else if (team1Score < team2Score){
                        team2totScore +=3;
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    else if (team1Score == team2Score){
                        team1totScore +=1;
                        team2totScore +=1;
                        outTeam1.printf(""+team1totScore+"\n");
                        outTeam2.printf(""+team2totScore+"\n");
                    }
                    //
                    if(team3Score > team10Score){
                        team3totScore +=3;
                        outTeam3.printf(""+team3totScore+"\n");
                    }
                    
                    else if (team3Score < team10Score){
                        team10totScore +=3;
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    else if (team3Score == team10Score){
                        team3totScore +=1;
                        team10totScore +=1;
                        outTeam3.printf(""+team3totScore+"\n");
                        outTeam10.printf(""+team10totScore+"\n");
                    }
                    //
                    if(team4Score > team9Score){
                        team4totScore +=3;
                        outTeam4.printf(""+team4totScore+"\n");
                    }
                    
                    else if (team4Score < team9Score){
                        team9totScore +=3;
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    else if (team4Score == team9Score){
                        team4totScore +=1;
                        team9totScore +=1;
                        outTeam4.printf(""+team4totScore+"\n");
                        outTeam9.printf(""+team9totScore+"\n");
                    }
                    //
                    if(team5Score > team8Score){
                        team5totScore +=3;
                        outTeam5.printf(""+team5totScore+"\n");
                    }
                    
                    else if (team5Score < team8Score){
                        team8totScore +=3;
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    else if (team5Score == team8Score){
                        team5totScore +=1;
                        team8totScore +=1;
                        outTeam5.printf(""+team5totScore+"\n");
                        outTeam8.printf(""+team8totScore+"\n");
                    }
                    //
                    if(team6Score > team7Score){
                        team6totScore +=3;
                        outTeam6.printf(""+team6totScore+"\n");
                    }
                    
                    else if (team6Score < team7Score){
                        team7totScore +=3;
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    else if (team6Score == team7Score){
                        team6totScore +=1;
                        team7totScore +=1;
                        outTeam6.printf(""+team6totScore+"\n");
                        outTeam7.printf(""+team7totScore+"\n");
                    }
                    
                    // System.exit(0); and thank the user
                    outTeam1.close();
                    outTeam2.close();
                    outTeam3.close();
                    outTeam4.close();
                    outTeam5.close();
                    outTeam6.close();
                    outTeam7.close();
                    outTeam8.close();
                    outTeam9.close();
                    outTeam10.close();
                    outRounds.printf("Round 9\n"+team1Name+" "+team1Score+"-"+team2Score+" "+team2Name+"\n"
                                                +team3Name+" "+team3Score+"-"+ team10Score +" "+team10Name+"\n"
                                                +team4Name+" "+team4Score+"-"+ team9Score +" "+team9Name+"\n"
                                                +team5Name+" "+team5Score+"-"+ team8Score +" "+team8Name+"\n"
                                                +team6Name+" "+team6Score+"-"+ team7Score +" "+team7Name+"\n");
                    outRounds.close();
                    JOptionPane.showMessageDialog (null,"Round "+counter+" scores have been saved!");
                    resetTxtFields();
                    dispose();
                    getTeamTotalScores();
                    System.exit(0);
                    team1totScore = 0;
                    team2totScore = 0;
                    team3totScore = 0;
                    team4totScore = 0;
                    team5totScore = 0;
                    team6totScore = 0;
                    team7totScore = 0;
                    team8totScore = 0;
                    team9totScore = 0;
                    team10totScore =0;
                    break;
            }
        }
      }
        
        catch(IOException | NumberFormatException exx ) 
      {
        //e.printStackTrace();
          //System.out.println(e + "ERROR");
          
        JOptionPane.showMessageDialog (null,"Make Sure you are entering only numbers in the space provided" 
                                                     +" or there has been problem with the data. Please contact customer care representative!"); 
        
      }
        
       // System.out.println("hello from bottom");
      
    }//GEN-LAST:event_saveButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegularRefereeViewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegularRefereeViewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegularRefereeViewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegularRefereeViewWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegularRefereeViewWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exitButton;
    private javax.swing.JTextField headerField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JButton saveButton;
    private javax.swing.JLabel team1Label;
    private javax.swing.JTextField team1TextField;
    private javax.swing.JLabel teamHeaderLabel;
    private javax.swing.JLabel teamScoreLabel;
    // End of variables declaration//GEN-END:variables

    public void getTeamTotalScores(){
        
        int sumTeam1 = 0;
        int sumTeam2 = 0;
        int sumTeam3 = 0;
        int sumTeam4 = 0;
        int sumTeam5 = 0;
        int sumTeam6 = 0;
        int sumTeam7 = 0;
        int sumTeam8 = 0;
        int sumTeam9 = 0;
        int sumTeam10 = 0;
        
        String line1 =null;
        String line2 =null;
        String line3 =null;
        String line4 =null;
        String line5 =null;
        String line6 =null;
        String line7 =null;
        String line8 =null;
        String line9 =null;
        String line10 =null;
        
        
        TreeMap<Integer, String> tmap = new TreeMap<Integer, String>();
        
        Collection c = tmap.values();
        Set set = tmap.entrySet();
        Iterator iterator = set.iterator();
        
        try{
            
            inTeam1 = new BufferedReader(new FileReader("Team1.txt"));
            inTeam2 = new BufferedReader(new FileReader("Team2.txt"));
            inTeam3 = new BufferedReader(new FileReader("Team3.txt"));
            inTeam4 = new BufferedReader(new FileReader("Team4.txt"));
            inTeam5 = new BufferedReader(new FileReader("Team5.txt"));
            inTeam6 = new BufferedReader(new FileReader("Team6.txt"));
            inTeam7 = new BufferedReader(new FileReader("Team7.txt"));
            inTeam8 = new BufferedReader(new FileReader("Team8.txt"));
            inTeam9 = new BufferedReader(new FileReader("Team9.txt"));
            inTeam10 = new BufferedReader(new FileReader("Team10.txt"));
            
            Scanner in1 = new Scanner(inTeam1);
            Scanner in2 = new Scanner(inTeam2);
            Scanner in3 = new Scanner(inTeam3);
            Scanner in4 = new Scanner(inTeam4);
            Scanner in5 = new Scanner(inTeam5);
            Scanner in6 = new Scanner(inTeam6);
            Scanner in7 = new Scanner(inTeam7);
            Scanner in8 = new Scanner(inTeam8);
            Scanner in9 = new Scanner(inTeam9);
            Scanner in10 = new Scanner(inTeam10);
           
            //team 1 sum of scores
            while ((line1 = inTeam1.readLine()) !=null) //gets team 1 sum
            {
             while (in1.hasNextInt())
             {
                 
                 team1totScore = in1.nextInt();
                 sumTeam1 += team1totScore;
                 //System.out.println(team1totScore + " hello");
             }
           } 
          //  System.out.println(team1Name+ " total score " +sumTeam1);
            
            //get the team 2 sum
            while ((line2 = inTeam2.readLine()) != null)
            {
             while (in2.hasNextInt())
             {
                 team2totScore = in2.nextInt();
                 sumTeam2 += team2totScore;
             }
            }
          //  System.out.println(team2Name+ " total score " +sumTeam2);
            
            //get the team 3 sum
            while ((line3 = inTeam3.readLine()) != null)
            {
             while (in3.hasNextInt())
             {
                 team3totScore = in3.nextInt();
                 sumTeam3 += team3totScore;
             }
            }
          //  System.out.println(team3Name+ " total score " +sumTeam3);
            
            // get the team 4 sum
            while ((line4 = inTeam4.readLine()) != null)
            {
             while (in4.hasNextInt())
             {
                 team4totScore = in4.nextInt();
                 sumTeam4 += team4totScore;
             }
            }
          //  System.out.println(team4Name+ " total score " +sumTeam4);
            
            // get team 5 sum
            while ((line5 = inTeam5.readLine()) != null)
            {
             while (in5.hasNextInt())
             {
                 team5totScore = in5.nextInt();
                 sumTeam5 += team5totScore;
             }
            }
          //  System.out.println(team5Name+ " total score " +sumTeam5);
            
            //get team 6 sum
            while ((line6 = inTeam6.readLine()) != null)
            {
             while (in6.hasNextInt())
             {
                 team6totScore = in6.nextInt();
                 sumTeam6 += team6totScore;
             }
            }
           // System.out.println(team6Name+ " total score " +sumTeam6);
            
            //get team 7 sum
            while ((line7 = inTeam7.readLine()) != null)
            {
             while (in7.hasNextInt())
             {
                 team7totScore = in7.nextInt();
                 sumTeam7 += team7totScore;
             }
            }
          //  System.out.println(team7Name+ " total score " +sumTeam7);
            
            // get team 8 sum 
            while ((line8 = inTeam8.readLine()) != null)
            {
             while (in8.hasNextInt())
             {
                 team8totScore = in8.nextInt();
                 sumTeam8 += team8totScore;
             }
            }
          //  System.out.println(team8Name+ " total score " +sumTeam8);
            
            // get team 9 sum 
            while ((line9 = inTeam9.readLine()) != null)
            {
             while (in9.hasNextInt())
             {
                 team9totScore = in9.nextInt();
                 sumTeam9 += team9totScore;
             }
            }
          //  System.out.println(team9Name+ " total score " +sumTeam9);
            
            //get team 10 sum 
            while ((line10 = inTeam10.readLine()) != null)
            {
             while (in10.hasNextInt())
             {
                 team10totScore = in10.nextInt();
                 sumTeam10 += team10totScore;
             }
            }
           // System.out.println(team10Name+ " total score " +sumTeam10);
            
           /* JOptionPane.showMessageDialog (null,team1Name + sumTeam1+"\n" 
                                                 +team2Name + sumTeam2 +"\n" 
                                                 +team3Name + sumTeam3 +"\n" 
                                                 +team4Name + sumTeam4 +"\n" 
                                                 +team5Name + sumTeam5 +"\n" 
                                                 +team6Name + sumTeam6 +"\n" 
                                                 +team7Name + sumTeam7 +"\n" 
                                                 +team8Name + sumTeam8 +"\n" 
                                                 +team9Name + sumTeam9 +"\n" 
                                                 +team10Name + sumTeam10);*/
            
        
            tmap.put(sumTeam1,team1Name);
            tmap.put(sumTeam2,team2Name);
            tmap.put(sumTeam3,team3Name);
            tmap.put(sumTeam4,team4Name);
            tmap.put(sumTeam5,team5Name);
            tmap.put(sumTeam6,team6Name);
            tmap.put(sumTeam7,team7Name);
            tmap.put(sumTeam8,team8Name);
            tmap.put(sumTeam9,team9Name);
            tmap.put(sumTeam10,team10Name);
           
            int lastkey1 = tmap.lastKey();
            String value = tmap.get(lastkey1);
           
            tmap.remove(lastkey1);
          
            int lastkey2 = tmap.lastKey();
            String value2 = tmap.get(lastkey2);
         
            JOptionPane.showMessageDialog (null,"The winner is: "+value+" The runner up is: "+value2);
        
        }
        
        
        
        catch(Exception ex)
        {
           // ex.printStackTrace();
            System.out.println("No such file in directory!");
        }
        
    }
    
    public void resetTxtFields()
    {
        team1TextField.setText("");
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jTextField9.setText("");
    }   
}