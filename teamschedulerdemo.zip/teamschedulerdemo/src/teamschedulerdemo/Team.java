/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teamschedulerdemo;

public class Team {
    
    int[] teamScores; // size = 1-10 depending on + of teams
   String teamName; // name of team
   int teamPosition; // what number this team is. Should be a number in teamScores starting at 0.
   
   //scoring guidelines: 0 = haven't played, 1 - win, 2 - loss, 3 - tie, 4 = Can't play itself.
    
    public Team(int numberOfTeams, int position, String name)
    {
        teamScores = new int[numberOfTeams];
        teamName = name;
        teamPosition = position;
        teamScores[teamPosition] = 4;
    }
    
    //returns the score for Team A's match vs the Opponent mentioned in the parameter. 
    //See scoring guidelines above for the meaning of scores.
    public int getScores(int OpponentPosition)
    {
      //System.out.println("hello"); 
      return teamScores[OpponentPosition];
      
    }
    public void setScores(int teamPosition, int score)
    {
        this.teamPosition = teamPosition;
        teamScores[teamPosition] = score;

    }
    
}