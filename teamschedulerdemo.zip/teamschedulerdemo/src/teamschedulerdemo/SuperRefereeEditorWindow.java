
package teamschedulerdemo;
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
import java.awt.List;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Scanner;
//import java.time.LocalDate;

public class SuperRefereeEditorWindow extends javax.swing.JFrame  {

  //main method
    
    public static int dates;
    public static SimpleDateFormat ddmmyy =new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    
    public SuperRefereeEditorWindow() {
            initComponents();
            
            jTextField1.setEditable(true);
            jTextField2.setEditable(true);
            jTextField3.setEditable(true);
            jTextField4.setEditable(true);
            jTextField5.setEditable(true);
            jTextField6.setEditable(true);
            jTextField7.setEditable(true);
            jTextField8.setEditable(true);
            jTextField9.setEditable(true);
            jTextField10.setEditable(true);
}
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField36 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField33 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jTextField40 = new javax.swing.JTextField();
        jTextField41 = new javax.swing.JTextField();
        jTextField42 = new javax.swing.JTextField();
        jTextField43 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jTextField26 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        headerLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jbeginningDateLabel = new javax.swing.JLabel();
        endDateLabel = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        checkDateButton = new javax.swing.JButton();

        jLabel11.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel11.setText("Scores");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        headerLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        headerLabel.setText("Super Referee Editor Window View");

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel1.setText("Team Name 1: ");

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel2.setText("Team Name 2: ");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel3.setText("Team Name 4: ");

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel4.setText("Team Name 3: ");

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel5.setText("Team Name 5: ");

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel6.setText("Team Name 6: ");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel7.setText("Team Name 7: ");

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel8.setText("Team Name 8: ");

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel9.setText("Team Name 9: ");

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel10.setText("Team Name 10: ");

        jbeginningDateLabel.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jbeginningDateLabel.setText("Beginning Date");

        endDateLabel.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        endDateLabel.setText("End Date");

        jTextField11.setText("dd/mm/yyyy");

        jTextField12.setText("dd/mm/yyyy");

        saveButton.setText("Save");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        checkDateButton.setText("Check Date");
        checkDateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkDateButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jbeginningDateLabel)
                                    .addComponent(endDateLabel)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel8)
                                        .addComponent(jLabel9)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addGap(2, 2, 2)
                                            .addComponent(jLabel1)
                                            .addGap(25, 25, 25)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10)
                                    .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(22, 22, 22)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(checkDateButton))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 394, Short.MAX_VALUE)
                        .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(headerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(headerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(checkDateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jbeginningDateLabel))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(endDateLabel))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
       
        if (getDuplicats() == false)
        {
            
            JOptionPane.showMessageDialog (null,"You have successfully created teams and your round match ups have been created as well.");
        //create teams 
        try
            { 
          PrintWriter out = new PrintWriter (new BufferedWriter(new FileWriter("TEAM_NAMES.txt",true)));
          
          out.printf(jTextField1.getText()+"\n" +jTextField2.getText()+"\n" +jTextField3.getText()+"\n" +jTextField4.getText()+"\n" +jTextField5.getText()
          +"\n" +jTextField6.getText()+"\n" +jTextField7.getText()+"\n" +jTextField8.getText()+"\n" +jTextField9.getText()+"\n"+jTextField10.getText());
          out.close();
            }
            
        catch(Exception exception)
            {
         // exception.printStackTrace();
          JOptionPane.showMessageDialog (null,"There has been problem with the data. Please contact "
                  + "customer care representative!");
          
            }
        }
       //another try and catch here to get the match up
       try{ 

            String inputFile = "TEAM_NAMES.txt";
            String line =null;
            Scanner s = new Scanner(System.in);
            String scanner ="";
            String temp; //holds the name of team
            int k = 0;
            Team[] teamArray = new Team[10];

            BufferedReader in = new BufferedReader(new FileReader(inputFile));
            PrintWriter writer = new PrintWriter("TEAM_NAMES.txt");

            PrintWriter out = new PrintWriter (new BufferedWriter(new FileWriter("ROUNDS.txt",true)));
            boolean flag = false;
          while ((line = in.readLine()) !=null || k<=9)
          {    
              temp = line;//reads in team names from a file

                  teamArray[k] = new Team(10, k, temp);  //passes in number of teams, their position and their name
                  k++;
          }

            Team tempTeam;
            int rounds = teamArray.length - 1;
            int counter = 0;
            int count = 0;
            int y = 0;
            int z = teamArray.length - 1;

            while (rounds > counter)
            {
             out.printf("Round "+ (counter+1+"\n"));
                while (y < z)
                {
                   // System.out.println(teamArray[y].teamName + " vs. " + teamArray[z].teamName + "                  ");
                    out.printf(teamArray[y].teamName + " vs. " + teamArray[z].teamName + "                  \n");
                     y++;
                     z--;

            }
                y = 0;
                z = teamArray.length - 1;
                tempTeam = teamArray[teamArray.length - 1];
                k = teamArray.length - 1;
               count++;
                while (k > 1)
                {
                    teamArray[k] = teamArray[k-1];
                    k--;
                }  
                teamArray[1] = tempTeam;
                counter++; 
                
            }
            out.close();
            dispose();
        }
        catch (Exception e)
        {
         // e.printStackTrace();
          JOptionPane.showMessageDialog (null,"There has been problem with the data. Please contact "
                  + "customer care representative!");
        }
      
         
    }//GEN-LAST:event_saveButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        
       // System.exit(0);
        dispose();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void checkDateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkDateButtonActionPerformed
        // TODO add your handling code here:
        
        try{
            
       Calendar c1 = GregorianCalendar.getInstance();
 
        
        String begDate = jTextField11.getText();
 
        
        String endDate = jTextField12.getText();
 
        Date beginningD =  ddmmyy.parse(begDate);
        Date endD  =  ddmmyy.parse(endDate);
 
        int days = daysBetween(beginningD, endD);
 
        int saturdays = (days/Calendar.SATURDAY)+1;
       
        ArrayList<Date> dates = new ArrayList<Date>();
 
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(beginningD);

        while (calendar.getTime().before(endD))
        {
         
         Date result = calendar.getTime();
        dates.add(result);
    
         calendar.add(Calendar.DATE, 7);
        }
        dates.add(endD);
       
        
        if (saturdays < 5){
           JOptionPane.showMessageDialog (null,"Not enough days!"); 
            
        }
        
        else if (saturdays > 9){
            JOptionPane.showMessageDialog (null,"The date is out of the range allowed to complete the season!"); 
            jTextField1.setEditable(false);
            jTextField2.setEditable(false);
            jTextField3.setEditable(false);
            jTextField4.setEditable(false);
            jTextField5.setEditable(false);
            jTextField6.setEditable(false);
            jTextField7.setEditable(false);
            jTextField8.setEditable(false);
            jTextField9.setEditable(false);
            jTextField10.setEditable(false);
        }
        
        else if (saturdays > 5 && saturdays < 9 )
        {
        JOptionPane.showMessageDialog (null,"Days between " + ddmmyy.format(beginningD) + " and " + ddmmyy.format(endD)
                                        +"\nYou have " + (days) + " days to finish this Event."
                                         + "\nYou have " + (saturdays) + " saturdays to finish this game\n"
                                            +dates+"\n");    
            jTextField1.setEditable(true);
            jTextField2.setEditable(true);
            jTextField3.setEditable(true);
            jTextField4.setEditable(true);
            jTextField5.setEditable(true);
            jTextField6.setEditable(true);
            jTextField7.setEditable(true);
            jTextField8.setEditable(true);
            jTextField9.setEditable(true);
            jTextField10.setEditable(true);
        }
  
    }
       
       catch(Exception e){
           e.printStackTrace();
       }
    }//GEN-LAST:event_checkDateButtonActionPerformed

   
    public static void main(String args[]) {
    	
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        
        catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SuperRefereeEditorWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SuperRefereeEditorWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SuperRefereeEditorWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SuperRefereeEditorWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton checkDateButton;
    private javax.swing.JLabel endDateLabel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel headerLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel jbeginningDateLabel;
    private javax.swing.JButton saveButton;
    // End of variables declaration//GEN-END:variables

    public boolean getDuplicats(){
        
        
        if(jTextField1.getText().equals(jTextField2.getText()) || jTextField1.getText().equals(jTextField3.getText()) || jTextField1.getText().equals(jTextField4.getText()) 
                || jTextField1.getText().equals(jTextField5.getText()) || jTextField1.getText().equals(jTextField6.getText())|| jTextField1.getText().equals(jTextField6.getText())
                || jTextField1.getText().equals(jTextField8.getText()) || jTextField1.getText().equals(jTextField9.getText())|| jTextField1.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names");
            return true;
        }
        else if (jTextField2.getText().equals(jTextField3.getText()) || jTextField2.getText().equals(jTextField4.getText()) || jTextField2.getText().equals(jTextField5.getText())
                || jTextField2.getText().equals(jTextField6.getText()) || jTextField2.getText().equals(jTextField7.getText())
                || jTextField2.getText().equals(jTextField8.getText()) || jTextField2.getText().equals(jTextField9.getText())
                || jTextField2.getText().equals(jTextField10.getText()))
        {
              JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names"); 
              return true;
        }
        
        else if (jTextField3.getText().equals(jTextField4.getText()) || jTextField3.getText().equals(jTextField5.getText()) || jTextField3.getText().equals(jTextField6.getText())
                || jTextField3.getText().equals(jTextField7.getText()) || jTextField3.getText().equals(jTextField8.getText())
                || jTextField3.getText().equals(jTextField9.getText()) || jTextField3.getText().equals(jTextField10.getText()))
        {
              JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names"); 
              return true;
        }
        else if (jTextField4.getText().equals(jTextField5.getText()) || jTextField4.getText().equals(jTextField6.getText())
                || jTextField4.getText().equals(jTextField7.getText()) || jTextField4.getText().equals(jTextField8.getText())
                || jTextField4.getText().equals(jTextField9.getText()) || jTextField4.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names");
            return true;
        }
        
        else if (jTextField5.getText().equals(jTextField6.getText()) || jTextField5.getText().equals(jTextField7.getText())
                || jTextField5.getText().equals(jTextField8.getText()) || jTextField5.getText().equals(jTextField9.getText())
                || jTextField5.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names"); 
            return true;
        }
        
        else if (jTextField6.getText().equals(jTextField7.getText()) || jTextField6.getText().equals(jTextField8.getText())
                || jTextField6.getText().equals(jTextField9.getText()) || jTextField6.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names"); 
            return true;
        }
        
        else if (jTextField7.getText().equals(jTextField8.getText()) || jTextField7.getText().equals(jTextField9.getText())
                || jTextField7.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names"); 
            return true;
        }
        
        else if (jTextField8.getText().equals(jTextField9.getText()) || jTextField8.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names");
            return true;
        }
        
        else if (jTextField9.getText().equals(jTextField10.getText()))
        {
            JOptionPane.showMessageDialog (null,"Same Team Names Please choose different Team Names");
            return true;
        } 
        return false;
    }
    public static int daysBetween(Date d1, Date d2)
 {
   return (int)( (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
   
 }
    
}

