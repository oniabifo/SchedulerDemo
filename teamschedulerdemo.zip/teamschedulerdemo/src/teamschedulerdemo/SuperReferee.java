
package teamschedulerdemo;


public class SuperReferee {
    private String name;
    private int validationCode;
    private String passWord;
    
   public SuperReferee(String pName, int pValidationCode, String pPassWord){
       this.name = pName;
       this.validationCode = pValidationCode;
       this.passWord = pPassWord;
       
   }
   
   public String getName(){
       
       return name;
   }
   
   public int getValidationCode(){
       
       return validationCode;
   }
   
   public String getPassWord(){
       
       return passWord;
   }
    
}
