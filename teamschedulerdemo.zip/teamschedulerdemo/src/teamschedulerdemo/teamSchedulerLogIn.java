		package teamschedulerdemo;

		import javax.swing.JOptionPane;


		public class teamSchedulerLogIn extends javax.swing.JFrame 
		{

		   
		    public teamSchedulerLogIn() {
		        initComponents();
		        
		        
		    }

		    
		    @SuppressWarnings("unchecked")
		    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
		    private void initComponents() {

		        exitButton2 = new javax.swing.JButton();
		        createNewAccButton = new javax.swing.JButton();
		        header = new javax.swing.JLabel();
		        logInNameLabel = new javax.swing.JLabel();
		        logInNameField = new javax.swing.JTextField();
		        passwordLabel = new javax.swing.JLabel();
		        passwordField = new javax.swing.JTextField();
		        logInButton = new javax.swing.JButton();
		        exitButton = new javax.swing.JButton();
		        jLabel1 = new javax.swing.JLabel();
		        validationCodeLabel = new javax.swing.JLabel();
		        validationCodeField = new javax.swing.JTextField();

		        exitButton2.setText("Exit Button 2");
		        exitButton2.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                exitButton2ActionPerformed(evt);
		            }
		        });

		        createNewAccButton.setText("Create New Account");
		        createNewAccButton.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                createNewAccButtonActionPerformed(evt);
		            }
		        });

		        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		        header.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
		        header.setText("Team Scheduler Log In Demo Window");

		        logInNameLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
		        logInNameLabel.setText("Log In Name: ");

		        passwordLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
		        passwordLabel.setText("Log In Password:");

		        logInButton.setText("Log In");
		        logInButton.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                logInButtonActionPerformed(evt);
		            }
		        });

		        exitButton.setText("Exit");
		        exitButton.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                exitButtonActionPerformed(evt);
		            }
		        });

		        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N

		        validationCodeLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
		        validationCodeLabel.setText("Validation Code:");

		        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		        getContentPane().setLayout(layout);
		        layout.setHorizontalGroup(
		            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
		            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
		                .addContainerGap(70, Short.MAX_VALUE)
		                .addComponent(header)
		                .addGap(85, 85, 85))
		            .addGroup(layout.createSequentialGroup()
		                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
		                    .addGroup(layout.createSequentialGroup()
		                        .addGap(21, 21, 21)
		                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
		                            .addComponent(logInNameLabel)
		                            .addComponent(passwordLabel)
		                            .addGroup(layout.createSequentialGroup()
		                                .addComponent(validationCodeLabel)
		                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
		                                .addComponent(jLabel1)))
		                        .addGap(30, 30, 30)
		                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
		                            .addComponent(logInNameField, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
		                            .addComponent(passwordField)
		                            .addComponent(validationCodeField)))
		                    .addGroup(layout.createSequentialGroup()
		                        .addGap(73, 73, 73)
		                        .addComponent(logInButton, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
		                        .addGap(69, 69, 69)
		                        .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
		                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		        );
		        layout.setVerticalGroup(
		            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
		            .addGroup(layout.createSequentialGroup()
		                .addGap(16, 16, 16)
		                .addComponent(header)
		                .addGap(30, 30, 30)
		                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
		                    .addComponent(logInNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
		                    .addComponent(logInNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
		                .addGap(18, 18, 18)
		                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
		                    .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
		                    .addComponent(passwordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
		                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
		                    .addGroup(layout.createSequentialGroup()
		                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
		                        .addComponent(jLabel1)
		                        .addGap(123, 123, 123))
		                    .addGroup(layout.createSequentialGroup()
		                        .addGap(18, 18, 18)
		                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
		                            .addComponent(validationCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
		                            .addComponent(validationCodeField, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
		                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
		                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
		                    .addComponent(logInButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
		                    .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
		                .addContainerGap())
		        );

		        pack();
		    }// </editor-fold>//GEN-END:initComponents

		    private void logInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logInButtonActionPerformed
		        
		        SuperReferee mySuperReferee = new SuperReferee("dejan",123,"swe2313");
		        SuperReferee myRegRef = new SuperReferee("dejan",321,"swe2313");
		        SuperReferee generalPublic = new SuperReferee("dejan",111,"swe2313");
		        
		        try{
		        int validCode = Integer.parseInt(validationCodeField.getText());
		        
		        if ((logInNameField.getText().toLowerCase().equals("dejan")) && (validCode == 123) 
		                && (passwordField.getText().equals("swe2313"))) {
		            
		            JOptionPane.showMessageDialog (null,"You are now logged in as a Super Referee.");
		            SuperRefereeEditorWindow myEditorWindow = new SuperRefereeEditorWindow();
		            myEditorWindow.setVisible(true);
		            myEditorWindow.setLocation(730,20);
		        }
		        else if((logInNameField.getText().toLowerCase().equals("dejan")) && (validCode == 321) 
		                && (passwordField.getText().equals("swe2313"))){
		           // System.out.println("Good");
		            JOptionPane.showMessageDialog (null,"You are logged in as a Regular Referee.");
		            RegularRefereeViewWindow regularRef = new RegularRefereeViewWindow();
		            regularRef.setVisible(true);
		            regularRef.setLocation(820,20);
		            
		        }
		        
		        else if((logInNameField.getText().toLowerCase().equals("dejan")) && (validCode == 111) 
		                && (passwordField.getText().equals("swe2313"))){
		          
		            JOptionPane.showMessageDialog (null,"You are logged in as a General Public.");
		            
		            ScheduleView view = new ScheduleView ();
		            view.setVisible(true);
		            view.setLocation(250,20);
		            
		            ViewScores generalpublic = new ViewScores();
		            generalpublic.setVisible(true);
		            generalpublic.setLocation(820,20);
		        }
		       
		        else 
		            JOptionPane.showMessageDialog (null,"The user does not exist, please make sure you are entering the "
		                    + "right information! ");
		           
		        }
		        catch(NumberFormatException e) {
		            
		            System.out.println("Please enter a number in a validation text box");
		            
		        }
		    }//GEN-LAST:event_logInButtonActionPerformed

		    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
		        // TODO add your handling code here:
		        System.exit(0);
		    }//GEN-LAST:event_exitButtonActionPerformed

		    private void createNewAccButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createNewAccButtonActionPerformed
		        // TODO add your handling code here:
		        NewUserWindow myNewUserWindow = new NewUserWindow();
		        myNewUserWindow.setVisible(true);
		        
		    }//GEN-LAST:event_createNewAccButtonActionPerformed

		    private void exitButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButton2ActionPerformed
		        // TODO add your handling code here:
		        System.exit(0);
		    }//GEN-LAST:event_exitButton2ActionPerformed

		    /**
		     * @param args the command line arguments
		     */
		    public static void main(String args[]) {
		        /* Set the Nimbus look and feel */
		        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
		         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
		         */
		        try {
		            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
		                if ("Nimbus".equals(info.getName())) {
		                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
		                    break;
		                }
		            }
		        } catch (ClassNotFoundException ex) {
		            java.util.logging.Logger.getLogger(teamSchedulerLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		        } catch (InstantiationException ex) {
		            java.util.logging.Logger.getLogger(teamSchedulerLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		        } catch (IllegalAccessException ex) {
		            java.util.logging.Logger.getLogger(teamSchedulerLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
		            java.util.logging.Logger.getLogger(teamSchedulerLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		        }
		        //</editor-fold>

		        /* Create and display the form */
		        java.awt.EventQueue.invokeLater(new Runnable() {
		            public void run() {
		                new teamSchedulerLogIn().setVisible(true);
		            }
		        });
		    }

		    // Variables declaration - do not modify//GEN-BEGIN:variables
		    private javax.swing.JButton createNewAccButton;
		    private javax.swing.JButton exitButton;
		    private javax.swing.JButton exitButton2;
		    private javax.swing.JLabel header;
		    private javax.swing.JLabel jLabel1;
		    private javax.swing.JButton logInButton;
		    private javax.swing.JTextField logInNameField;
		    private javax.swing.JLabel logInNameLabel;
		    private javax.swing.JTextField passwordField;
		    private javax.swing.JLabel passwordLabel;
		    private javax.swing.JTextField validationCodeField;
		    private javax.swing.JLabel validationCodeLabel;
		    // End of variables declaration//GEN-END:variables
		}