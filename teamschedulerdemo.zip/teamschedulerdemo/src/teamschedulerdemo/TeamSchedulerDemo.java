
package teamschedulerdemo;
//main class
public class TeamSchedulerDemo {

   
    public static void main(String[] args) {
        
    	teamSchedulerLogIn myFrame = new teamSchedulerLogIn();
        myFrame.setVisible(true);
 
    }
    
}